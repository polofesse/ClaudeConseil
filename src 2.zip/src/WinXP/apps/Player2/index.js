import React from 'react';
import ReactPlayer from 'react-player/youtube';

const Beretta = () => (
  <ReactPlayer url="https://youtu.be/G3LIdOm00j4" width="100%" height="100%" />
);

export default Beretta;
