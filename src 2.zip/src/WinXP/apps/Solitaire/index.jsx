import React, { useEffect } from 'react';
import './index.css'; // Assurez-vous que ce fichier CSS est bien généré

const Solitaire = () => {
  useEffect(() => {
    // Appel à la fonction d'initialisation du jeu si nécessaire
    // initGame();
  }, []);

  return (
    <div className="window">
      <div className="window__inner">
        <div className="window__heading">
          <div className="window__heading-icon"></div>
          Solitaire
        </div>
        <div className="window__content">
          <div className="window__content-inner solitaire">
            <div className="deck">
              <div className="deck__pile"></div>
              <div className="deck__deal">
                <div className="card card--back"></div>
              </div>
            </div>
            <div className="board-deck">
              <div className="seven">
                <div className="card card--front"></div>
              </div>
              <div className="finish-deck">
                <div className="card card--back"></div>
              </div>
            </div>
          </div>
        </div>
        <button className="new-game">New Game</button>
      </div>
    </div>
  );
};

export default Solitaire;
