import React, { useState, useEffect } from 'react';
import ImageGallery from 'react-image-gallery';
import { getStorage, ref, listAll, getDownloadURL } from 'firebase/storage';
import { app } from './firebaseConfig'; // Chemin d'accès à adapter selon votre structure de fichiers
import 'react-image-gallery/styles/css/image-gallery.css';

const GalleryComponent = () => {
  const [images, setImages] = useState([]);
  const storage = getStorage(app); // Utiliser 'app' pour initialiser le stockage Firebase

  useEffect(() => {
    const storageRef = ref(storage, 'STILLS/FULL/');

    listAll(storageRef)
      .then(result => {
        const urls = [];
        result.items.forEach(imageRef => {
          getDownloadURL(imageRef).then(url => {
            urls.push({ original: url, thumbnail: url });
            setImages([...urls]);
          });
        });
      })
      .catch(error => {
        console.error('Erreur lors de la récupération des images:', error);
      });
  }, []);

  return <ImageGallery items={images} />;
};

export default GalleryComponent;
